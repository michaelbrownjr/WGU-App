package generics;

public class GenericEntity {
}
